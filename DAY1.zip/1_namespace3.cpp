﻿// 1_namespace3.cpp - 9page 내용
// 
#include <algorithm>

int main()
{
	int n = min(3, 2); // C++ 표준 함수. algorithm 헤더 필요
}
