#include <iostream>
#include <algorithm>

#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>

// unordered_set

int main()
{
	std::set<int> s;

	s.insert(50);
	s.insert(30);
	s.insert(70);


}