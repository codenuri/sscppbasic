// 4_STL_�����̳�1.cpp
#include <iostream>
#include <vector>

int main()
{
	int x[5] = { 1,2,3,4,5 };

	std::vector<int> v = { 1,2,3,4,5 };
}