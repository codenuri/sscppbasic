#include <iostream>

int x = 10;
int f1() { return x; }

int main()
{
	int v1 = 10, v2 = 20;

	v2 = v1;
	v1 = 20;

	f1() = 30; // ??
}