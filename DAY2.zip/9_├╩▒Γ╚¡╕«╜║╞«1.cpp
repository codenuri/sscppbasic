﻿// 6_초기화리스트1    85page ~
#include <iostream>

class Point
{
	int x, y;
public:
	Point(int a  = 0, int b = 0) 		
	{
		x = a; 
		y = b; 
	}
};
int main()
{
	Point pt(0, 0);
}




