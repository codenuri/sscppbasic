#include <iostream>
#include <string>
#include <vector>

int main()
{

}
