class Vector
{
public:
	Vector(int size) {}
};

void foo(Vector v) {}

int main()
{

}