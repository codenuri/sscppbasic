#include <iostream>
#include <string>
#include <vector>

void f1(std::string s) {}
void f2(std::vector v) {}

int main()
{
	f1("hello");
	f2(10);

	std::string s1("hello");
	std::vector<int> v1(10);
	
}

